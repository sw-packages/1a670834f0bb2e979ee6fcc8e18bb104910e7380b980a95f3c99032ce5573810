#define __CRT_STRSAFE_IMPL
#include <strsafe.h>
